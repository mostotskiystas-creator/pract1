from aiogram import Bot, Dispatcher
from config import TOKEN

bot = Bot(TOKEN)
dp = Dispatcher()