from aiogram import types
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from misc import bot, dp

@dp.message(Command('start'))
async def start(message: types.Message):
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='💎 TON')],
            [KeyboardButton(text='₿ BTC')],
            [KeyboardButton(text='Ξ ETH')],
        ], resize_keyboard=True)
    await message.answer('Вибери криптовалюту:', reply_markup=keyboard)