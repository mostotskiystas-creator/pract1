import asyncio
from misc import bot, dp
from handlers import start, price

async def main():
    print('Bot is running...')
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())